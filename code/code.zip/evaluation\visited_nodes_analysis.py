import argparse
import gc
import json
import os
import time
from pathlib import Path

import numpy as np
import torch

import traverse_strategies as ts
from core.config import (
    BASE_MODELS,
    DEFAULT_EMBEDDING_BATCH_SIZE,
    EMBEDDING_INDEX_MIN_SUCCESSORS,
)
from core.constants import (
    BFS_CAPPED_BASELINE_MODEL,
    BFS_UNCAPPED_BASELINE_MODEL,
    DEFAULT_RL_MODEL_PATH,
    EVALUATION_DIR,
    GLOVE_300D_PATH,
    LIGHTNING_MODELS_DIR,
    RL_BASELINE_MODEL,
)
from core.embeddings import STEmbedder, GloveEmbeder, DistanceMetric
from core.graph_config import (
    DEFAULT_GRAPH_NAME,
    canonical_graph_name,
    graph_arg,
    get_graph_label,
    get_graph_path,
    graph_choices,
)
from core.embedding_preload import preload_graph_embeddings, preload_rl_embeddings
from core.utils import (
    get_ablation_fine_tuned_models,
    get_ablation_model_names,
    get_embedding_cache_suffix,
    get_node_universe_for_graph,
    traverse_graph,
    get_fine_tuned_models,
    get_model_distance_metric,
    get_matryoshka_dims,
    load_causal_graph,
    load_rl_graph,
)

# -------------------------------------------------------------------------
# Global paths
# -------------------------------------------------------------------------

EVALUATION_OUTPUT_ROOT = EVALUATION_DIR


def build_output_paths(
    dataset_path: str,
    run_suffix: str,
    graph_name: str,
    ablation: bool = False,
):
    """
    Build output path from dataset name and run suffix.

    Example:
    data/datasets/msmarco_valid_filtered.json + v3
    ->
    data/evaluation/causenet/msmarco_valid/v3/visited_nodes_analysis.json
    """
    graph_name = canonical_graph_name(graph_name)
    dataset_stem = Path(dataset_path).stem
    dataset_name = dataset_stem.replace("_filtered", "")

    # Detect split automatically
    if "train" in dataset_name.lower():
        split = "train"
    elif "valid" in dataset_name.lower():
        split = "valid"
    elif "test" in dataset_name.lower():
        split = "test"
    else:
        split = "unknown"

    output_root = EVALUATION_OUTPUT_ROOT / "ablation" if ablation else EVALUATION_OUTPUT_ROOT
    output_dir = output_root / graph_name / dataset_name / run_suffix
    output_json_file = output_dir / "visited_nodes_analysis.json"

    return dataset_name, split, output_dir, str(output_json_file)


def load_results_file(output_json_file):
    """
    Load already collected results.

    This makes the script resumable.
    """
    if os.path.exists(output_json_file):
        with open(output_json_file, "r", encoding="utf-8") as file:
            return json.load(file)

    return []


def save_result(result_entry, output_json_file):
    """
    Append one finished result entry to the JSON file.
    """
    current_results = load_results_file(output_json_file)
    current_results.append(result_entry)

    with open(output_json_file, "w", encoding="utf-8") as file:
        json.dump(current_results, file, indent=4)

    print(
        f"Saved visited-node results for "
        f"'{result_entry['model']}' dim {result_entry.get('dimension')} "
        f"strategy {result_entry.get('analysis', {}).get('strategy')}"
    )


def already_done(existing_results, model, dimension=None, strategy=None):
    """
    Check whether this model/dimension/strategy was already collected.
    """
    for entry in existing_results:
        if entry.get("model") != model or entry.get("dimension") != dimension:
            continue

        if strategy is None:
            return True

        if entry.get("analysis", {}).get("strategy") == strategy:
            return True

    return False


def percentile(values, p):
    """
    Return percentile as float.
    """
    if not values:
        return 0.0

    return float(np.percentile(values, p))


def run_visited_nodes_loop(
        data,
        graph,
        embeder,
        strategy,
        strategy_name,
        description,
        config=None,
):
    """
    Run one traversal strategy and store raw visited-node data.

    This script is intentionally uncapped because it is used
    to determine p95 traversal limits later.
    """
    print(f"Starting visited-node collection: {description}")

    per_example = []
    successful_visited_counts = []
    all_visited_counts = []

    for i, item in enumerate(data):
        if i % 100 == 0:
            print(f"  Example {i}/{len(data)}...")

        cause = item["cause"]
        effect = item["effect"]

        # Skip examples not covered by graph
        if cause not in graph.nodes or effect not in graph.nodes:
            continue

        example_id = item.get("id", i)
        true_label = bool(item["answer"])

        start_time = time.time()

        strategy_config = config
        if strategy_name == "RL":
            strategy_config = dict(config) if config is not None else {}
            strategy_config["question"] = item.get(
                "question",
                f"can {cause} cause {effect}?"
            )

        path, visited_nodes = traverse_graph(
            graph,
            cause,
            effect,
            embeder,
            strategy,
            strategy_config,
        )

        end_time = time.time()

        pred_label = bool(path)
        path_length = len(path) if path else 0
        elapsed = end_time - start_time

        all_visited_counts.append(int(visited_nodes))

        if pred_label:
            successful_visited_counts.append(int(visited_nodes))

        per_example.append(
            {
                "id": example_id,
                "cause": cause,
                "effect": effect,
                "true": true_label,
                "pred": pred_label,
                "correct": pred_label == true_label,
                "nodes_visited": int(visited_nodes),
                "path_length": int(path_length),
                "time_sec": float(elapsed),
                "time_ms": float(elapsed * 1000),
                "path": path if path else [],
            }
        )

    summary = {
        "strategy": strategy_name,
        "num_examples": len(per_example),
        "num_successful_paths": len(successful_visited_counts),

        # Raw values for later plotting
        "visited_counts_all": all_visited_counts,
        "visited_counts_successful_only": successful_visited_counts,

        # Stats used later for config creation
        "max_visited_all": max(all_visited_counts) if all_visited_counts else 0,
        "max_visited_successful_only": (
            max(successful_visited_counts)
            if successful_visited_counts
            else 0
        ),
        "p95_visited_all": percentile(all_visited_counts, 95),
        "p95_visited_successful_only": percentile(
            successful_visited_counts,
            95
        ),

        # Full raw examples for later analysis
        "per_example": per_example,
    }

    print(
        f"Finished {strategy_name} | "
        f"Examples: {summary['num_examples']} | "
        f"Successful paths: {summary['num_successful_paths']} | "
        f"Max visited: {summary['max_visited_all']} | "
        f"P95 successful: {summary['p95_visited_successful_only']:.1f}"
    )

    return summary


def parse_args():
    parser = argparse.ArgumentParser(
        description="Collect uncapped visited-node distributions."
    )
    parser.add_argument(
        "dataset_path",
        help="Path to normalized dataset JSON file."
    )
    parser.add_argument(
        "--run-suffix",
        type=str,
        required=True,
        help="Final-training run suffix, e.g. v3.",
    )
    parser.add_argument(
        "--graph",
        type=graph_arg,
        choices=graph_choices(),
        default=DEFAULT_GRAPH_NAME,
        help="Graph to analyze with. Defaults to CauseNet.",
    )
    parser.add_argument(
        "--embedding-device",
        choices=("auto", "cpu", "cuda"),
        default="auto",
        help=(
            "Torch device for ST/GloVe embedding tensors and ST model encoding. "
            "Use cpu to benchmark traversal distance computation without GPU "
            "synchronization overhead. Default: auto."
        ),
    )
    parser.add_argument(
        "--embedding-batch-size",
        type=int,
        default=DEFAULT_EMBEDDING_BATCH_SIZE,
        help="Batch size used when loading or backfilling the ST embedding index.",
    )
    parser.add_argument(
        "--dim",
        type=int,
        default=None,
        help=(
            "Only collect visited-node distributions for this Matryoshka "
            "dimension. Required in --ablation mode."
        ),
    )
    parser.add_argument(
        "--ablation",
        action="store_true",
        help=(
            "Analyze the main Granite reference and all three "
            "activation/distance variants, skip baselines, and write under "
            "data/evaluation/ablation."
        ),
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    dataset_path = args.dataset_path
    run_suffix = args.run_suffix
    graph_name = args.graph
    graph_label = get_graph_label(graph_name)
    graph_path = get_graph_path(graph_name)

    if args.dim is not None and args.dim <= 0:
        raise ValueError("--dim must be greater than 0")
    if args.embedding_batch_size <= 0:
        raise ValueError("--embedding-batch-size must be greater than 0")
    if args.ablation and args.dim is None:
        raise ValueError("--ablation requires --dim, e.g. --dim 32")

    if args.ablation:
        model_queue = get_ablation_fine_tuned_models(run_suffix)
        expected_model_names = set(get_ablation_model_names(run_suffix))
        found_model_names = {Path(model_path).name for model_path in model_queue}
        missing_model_names = sorted(expected_model_names - found_model_names)
        if missing_model_names:
            raise FileNotFoundError(
                "The four-model ablation comparison is incomplete for run "
                f"suffix '{run_suffix}' in {LIGHTNING_MODELS_DIR}. Missing: "
                f"{missing_model_names}"
            )
    else:
        fine_tuned_models = get_fine_tuned_models(run_suffix)
        model_queue = list(BASE_MODELS) + fine_tuned_models

    print(f"Run suffix: {run_suffix}")
    print(f"Ablation mode: {args.ablation}")
    print(f"Graph: {graph_label} ({graph_name})")
    print(f"Graph path: {graph_path}")
    print(f"Embedding device: {args.embedding_device}")
    print(f"Embedding batch size: {args.embedding_batch_size}")
    if args.dim is not None:
        print(f"Restricted Matryoshka dim: {args.dim}")
    embedding_cache_suffix = get_embedding_cache_suffix(graph_name)
    node_universe = get_node_universe_for_graph(graph_name)
    if embedding_cache_suffix:
        print(f"Embedding cache suffix: {embedding_cache_suffix}")
    print(f"Embedding node universe: {node_universe}")
    print("Model queue:", model_queue)

    # RL still needs these parameters
    RL_ANALYSIS_CONFIG = {
        "rl_model_path": str(DEFAULT_RL_MODEL_PATH),
        "rl_beam_width": 50,
        "rl_max_path_len": 2,
        "rl_max_actions": 5000,
        "rl_max_visits": -1,
    }

    dataset_name, split, output_dir, output_json_file = build_output_paths(
        dataset_path,
        run_suffix,
        graph_name,
        ablation=args.ablation,
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Dataset: {dataset_name}")
    print(f"Split: {split}")
    print(f"Output directory: {output_dir}")

    print("Loading dataset...")
    with open(dataset_path, encoding="utf-8") as file:
        data = json.load(file)

    print("Loading graphs...")
    causal_graph = load_causal_graph(
        graph_path,
        use_inverse=False,
    )
    rl_graph = None
    if not args.ablation:
        rl_graph = load_rl_graph(
            graph_path,
            use_inverse=False,
        )

    existing_results = load_results_file(output_json_file)

    # -------------------------------------------------------------------------
    # BFS baseline
    # -------------------------------------------------------------------------
    has_bfs_uncapped_result = any(
        already_done(existing_results, model)
        for model in (BFS_UNCAPPED_BASELINE_MODEL, BFS_CAPPED_BASELINE_MODEL)
    )

    if args.ablation:
        print("\n=== skipping baselines in ablation mode ===")
    elif not has_bfs_uncapped_result:
        print("\n=== Running BFS Uncapped Baseline ===")

        bfs_result = run_visited_nodes_loop(
            data=data,
            graph=causal_graph,
            embeder=None,
            strategy=ts.bfs_traverse,
            strategy_name="BFS",
            description=f"BFS | {dataset_name} | {run_suffix}",
            config=None,
        )

        save_result(
            {
                "model": BFS_UNCAPPED_BASELINE_MODEL,
                "dimension": None,
                "dataset": dataset_name,
                "split": split,
                "run_suffix": run_suffix,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "analysis": bfs_result,
            },
            output_json_file,
        )
    else:
        print("\n=== skipping BFS Uncapped Baseline ===")

    existing_results = load_results_file(output_json_file)

    # -------------------------------------------------------------------------
    # RL baseline
    # -------------------------------------------------------------------------
    if args.ablation:
        pass
    elif not already_done(existing_results, RL_BASELINE_MODEL):
        print("\n=== Running RL Baseline ===")

        try:
            rl_embeder = GloveEmbeder(
                GLOVE_300D_PATH,
                DistanceMetric.COSINE,
                device=args.embedding_device,
            )

            preload_rl_embeddings(
                rl_embeder,
                rl_graph,
                data=data,
            )

            rl_result = run_visited_nodes_loop(
                data=data,
                graph=rl_graph,
                embeder=rl_embeder,
                strategy=ts.rl_traverse,
                strategy_name="RL",
                description=f"RL | {dataset_name} | {run_suffix}",
                config=RL_ANALYSIS_CONFIG,
            )

            save_result(
                {
                    "model": RL_BASELINE_MODEL,
                    "dimension": None,
                    "dataset": dataset_name,
                    "split": split,
                    "run_suffix": run_suffix,
                    "embedding_device": args.embedding_device,
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "analysis": rl_result,
                },
                output_json_file,
            )

            del rl_embeder
            gc.collect()

        except Exception as e:
            print(f"Failed RL: {e}")
    else:
        print("\n=== skipping RL Baseline ===")

    # -------------------------------------------------------------------------
    # Embedding-guided models
    # -------------------------------------------------------------------------
    for model_path in model_queue:
        model_name = model_path.split("/")[-1]

        print(f"\nCOLLECTING EMBEDDING STRATEGIES: {model_path}")

        try:
            distance_metric = get_model_distance_metric(model_path)
            print(f"Distance metric: {distance_metric}")

            main_embeder = STEmbedder(
                model_path=model_path,
                distance_metric=distance_metric,
                device=args.embedding_device,
                cache_suffix=embedding_cache_suffix,
                node_universe=node_universe,
            )

            # Collect one uncapped distribution per Matryoshka dimension.
            model_dim = main_embeder.get_model_dim()
            if args.dim is not None:
                if args.dim > model_dim:
                    raise ValueError(
                        f"Requested dim {args.dim}, but {model_path} only "
                        f"has {model_dim} embedding dimensions."
                    )
                matryoshka_dims = [args.dim]
            else:
                matryoshka_dims = get_matryoshka_dims(model_dim)

            print(f"Model dim: {model_dim}")
            print(f"Matryoshka dims: {matryoshka_dims}")

            semantic_config = {
                "embedding_index_min_successors": EMBEDDING_INDEX_MIN_SUCCESSORS
            }

            for dim in matryoshka_dims:
                existing_results = load_results_file(output_json_file)
                strategy_items = [
                    ("A*", ts.astar_traverse),
                    ("Dijkstra", ts.dijkstra_traverse),
                ]
                pending_strategy_items = [
                    (strategy_name, strategy)
                    for strategy_name, strategy in strategy_items
                    if not already_done(
                        existing_results,
                        model_name,
                        dim,
                        strategy_name,
                    )
                ]

                if not pending_strategy_items:
                    print(f"Skipping {model_name} dim {dim}")
                    continue

                main_embeder.set_matryoshka_dim(dim)
                print(
                    "Loading graph embedding index at Matryoshka dim "
                    f"{dim}."
                )
                indexed_graph = preload_graph_embeddings(
                    main_embeder,
                    causal_graph,
                    batch_size=args.embedding_batch_size,
                    save_cache=True,
                )
                runtime_config = dict(semantic_config)
                if indexed_graph is not None and main_embeder.has_embedding_index():
                    runtime_config["_indexed_graph"] = indexed_graph

                for strategy_name, strategy in pending_strategy_items:
                    print(f"\n--- Running {strategy_name} dim {dim} ---")

                    strategy_result = run_visited_nodes_loop(
                        data=data,
                        graph=causal_graph,
                        embeder=main_embeder,
                        strategy=strategy,
                        strategy_name=strategy_name,
                        description=(
                            f"{strategy_name} | {model_name} | dim {dim} | "
                            f"{dataset_name} | {run_suffix}"
                        ),
                        config=runtime_config,
                    )

                    save_result(
                        {
                            "model": model_name,
                            "model_path": model_path,
                            "dimension": dim,
                            "dataset": dataset_name,
                            "split": split,
                            "run_suffix": run_suffix,
                            "ablation": args.ablation,
                            "embedding_device": args.embedding_device,
                            "used_config": semantic_config,
                            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "analysis": strategy_result,
                        },
                        output_json_file,
                    )

            del main_embeder
            gc.collect()
            torch.cuda.empty_cache()

        except Exception as e:
            print(f"Error for {model_path}: {e}")

    print("\nVisited-node collection complete.")
    print(f"Output JSON: {output_json_file}")
