import argparse
import gc

import optuna
import pytorch_lightning as pl
import torch
import torch.nn.functional as F
from datasets import Dataset, load_from_disk
from sentence_transformers import SentenceTransformer
from torch import nn

import traverse_strategies as ts
from core.constants import ActivationFunc
from core.embeddings import DistanceMetric, STEmbedder
from core.utils import get_concept, traverse_graph, get_matryoshka_dims, parse_distance_metric

TARGET_EFFECTIVE_BATCH_SIZE = 128
MAX_TRAINING_BATCH_SIZE = 128


def str_to_bool(value: str) -> bool:
    if isinstance(value, bool):
        return value

    value = value.strip().lower()
    if value in {"true", "1", "yes", "y"}:
        return True
    elif value in {"false", "0", "no", "n"}:
        return False
    else:
        raise argparse.ArgumentTypeError(f"Boolean value expected, got: {value}")


def validate_training_args(
        batch_size,
        epochs,
        patience,
        target_effective_batch_size=TARGET_EFFECTIVE_BATCH_SIZE,
        max_batch_size=MAX_TRAINING_BATCH_SIZE,
):
    if batch_size <= 0:
        raise ValueError("batch_size must be > 0")
    if batch_size > max_batch_size:
        raise ValueError(f"batch_size must be <= {max_batch_size}")
    if target_effective_batch_size % batch_size != 0:
        raise ValueError(
            f"batch_size must divide {target_effective_batch_size} "
            "(e.g. 128, 64, 32, 16, 8)"
        )
    if epochs <= 0:
        raise ValueError("epochs must be > 0")
    if patience < 0:
        raise ValueError("patience must be >= 0")
    if patience >= epochs:
        print("Warning: patience >= epochs, so early stopping will probably not trigger.")


class MatryoshkaAStarLoss(nn.Module):
    def __init__(
            self,
            model,
            cls_activation_func,
            cls_distance_metric: DistanceMetric,
            cls_normalize: bool,
            matryoshka_dims: list[int] = None
    ):
        super().__init__()
        self.model = model
        self.distance_metric = cls_distance_metric
        self.activation_func = nn.ReLU() if cls_activation_func == ActivationFunc.RELU else nn.GELU()
        self.normalize = cls_normalize

        # If no explicit Matryoshka dimensions are given, just use the full embedding size.
        if matryoshka_dims is None:
            self.matryoshka_dims = [self.model.get_sentence_embedding_dimension()]
        else:
            # Sorting from large to small makes the truncation logic easier to reason about.
            self.matryoshka_dims = sorted(set(matryoshka_dims), reverse=True)

    def distance(self, a, b):
        if self.distance_metric == DistanceMetric.COSINE:
            if self.normalize:
                return 1 - (a * b).sum(dim=-1)

            return 1 - F.cosine_similarity(a, b, dim=-1)
        elif self.distance_metric == DistanceMetric.EUCLIDEAN:
            return torch.norm(a - b, dim=-1)
        else:
            raise ValueError(f"Unsupported metric: {self.distance_metric}")

    def get_raw_embeddings(self, texts):
        # We directly call the SentenceTransformer forward pass here instead of encode()
        # because this is used during training and needs gradients.
        features = self.model.tokenize(texts)
        features = {key: val.to(self.model.device) for key, val in features.items()}
        embeddings = self.model(features)["sentence_embedding"]
        return embeddings

    def compute_sub_loss(self, c_emb, e_emb, p_emb, n_emb):
        # Distances for the positive step on the path.
        d_cp = self.distance(c_emb, p_emb)
        d_pe = self.distance(p_emb, e_emb)

        # Distances for a negative alternative successor.
        d_cn = self.distance(c_emb, n_emb)
        d_ne = self.distance(n_emb, e_emb)

        # The idea is simple:
        # a good next node should make the overall route to the effect look better
        # than a bad successor.
        diff = (d_cp + d_pe) - (d_cn + d_ne)

        # If embeddings are not normalized explicitly, keep their norms roughly stable.
        embeddings_sum = (
                (torch.linalg.vector_norm(c_emb, dim=-1) - 1) ** 2
                + (torch.linalg.vector_norm(e_emb, dim=-1) - 1) ** 2
                + (torch.linalg.vector_norm(p_emb, dim=-1) - 1) ** 2
                + (torch.linalg.vector_norm(n_emb, dim=-1) - 1) ** 2
        )

        regularization = embeddings_sum.mean() if not self.normalize else 0.0

        return self.activation_func(diff).mean() + regularization

    def forward(self, sentence_features):
        # sentence_features contains:
        # [start_nodes, end_nodes, positives, negatives]
        c_raw = self.get_raw_embeddings(sentence_features[0])
        e_raw = self.get_raw_embeddings(sentence_features[1])
        p_raw = self.get_raw_embeddings(sentence_features[2])
        n_raw = self.get_raw_embeddings(sentence_features[3])

        total_loss = 0.0

        # Compute the loss for every Matryoshka slice and sum them up.
        for dim in self.matryoshka_dims:
            cf = c_raw[:, :dim]
            ef = e_raw[:, :dim]
            pf = p_raw[:, :dim]
            nf = n_raw[:, :dim]

            if self.normalize:
                cf = F.normalize(cf, p=2, dim=1)
                ef = F.normalize(ef, p=2, dim=1)
                pf = F.normalize(pf, p=2, dim=1)
                nf = F.normalize(nf, p=2, dim=1)

            total_loss += self.compute_sub_loss(cf, ef, pf, nf)

        return total_loss


class LitAStar(pl.LightningModule):
    def __init__(
            self,
            model_name,
            cls_activation_func,
            cls_distance_metric,
            cls_normalize,
            lr,
            cls_use_matryoshka,
            graph,
            batch_size,
    ):
        super().__init__()

        # The graph object is large and not something we want in Lightning's saved hparams.
        self.save_hyperparameters(ignore=["graph"])

        self.lr = lr
        self.graph = graph

        self.embedding_model = SentenceTransformer(model_name)
        self.embedding_model.train()

        model_dimension = self.embedding_model.get_sentence_embedding_dimension()
        matryoshka_dims = get_matryoshka_dims(model_dimension) if cls_use_matryoshka else [model_dimension]

        self.batch_size = batch_size

        self.loss_fn = MatryoshkaAStarLoss(
            self.embedding_model,
            cls_activation_func,
            cls_distance_metric,
            cls_normalize,
            matryoshka_dims
        )

        # val_cache stores node -> embedding for the current validation epoch.
        # result_cache stores (start, end) -> visited nodes, so repeated pairs are cheap.
        self.val_cache = {}
        self.val_text_to_idx = {}
        self.val_embedding_table = None
        self.result_cache = {}

    def on_validation_epoch_start(self):
        self.val_cache.clear()
        self.result_cache.clear()

        all_nodes = list(self.graph.nodes())

        if not all_nodes:
            return

        # Validation repeatedly queries embeddings for graph nodes.
        # So we precompute all node embeddings once per validation epoch.
        self.embedding_model.eval()
        with torch.no_grad():
            embeddings = self.embedding_model.encode(
                all_nodes,
                batch_size=self.batch_size * 16,
                convert_to_tensor=True,
                normalize_embeddings=self.loss_fn.normalize,
                show_progress_bar=False,
                device=self.device
            )

        self.val_embedding_table = nn.Embedding.from_pretrained(
            embeddings,
            freeze=True,
        )
        self.val_embedding_table.eval()
        self.val_text_to_idx = {
            node: index
            for index, node in enumerate(all_nodes)
        }
        self.val_cache = dict(zip(all_nodes, embeddings))

    def on_validation_epoch_end(self):
        # Free memory explicitly after each validation epoch.
        self.val_cache.clear()
        self.val_text_to_idx.clear()
        self.val_embedding_table = None
        self.result_cache.clear()

    def embed(self, text: str):
        # traverse_graph expects the model object to expose an embed() method.
        if text in self.val_cache:
            return self.val_cache[text]

        index = self.val_text_to_idx.get(text)
        if self.val_embedding_table is not None and index is not None:
            return self.val_embedding_table.weight[index]

        raise KeyError(text)

    def embed_many(self, texts):
        texts = list(texts)

        if not texts:
            dim = self.embedding_model.get_sentence_embedding_dimension()
            return torch.empty((0, dim), device=self.device)

        if self.val_embedding_table is not None:
            index_tensor = torch.as_tensor(
                [self.val_text_to_idx[text] for text in texts],
                device=self.device,
                dtype=torch.long,
            )

            with torch.no_grad():
                return self.val_embedding_table.weight.index_select(0, index_tensor)

        return torch.stack([
            self.val_cache[text]
            for text in texts
        ])

    def has_embedding_index(self):
        return self.val_embedding_table is not None

    def has_normalized_runtime_embeddings(self):
        return (
            self.loss_fn.distance_metric == DistanceMetric.COSINE
            and self.loss_fn.normalize
        )

    def get_distance(self, emb_a, emb_b):
        # traverse_graph also expects a distance function on the model side.
        if (
            self.loss_fn.distance_metric == DistanceMetric.COSINE
            and self.loss_fn.normalize
        ):
            return (1 - torch.dot(emb_a.flatten(), emb_b.flatten())).item()

        return self.loss_fn.distance(emb_a.unsqueeze(0), emb_b.unsqueeze(0)).item()

    def get_distances(self, emb_a, embeddings, assume_normalized=False):
        if isinstance(embeddings, torch.Tensor):
            if embeddings.numel() == 0:
                return []

            matrix = embeddings

            if matrix.dim() == 1:
                matrix = matrix.unsqueeze(0)
            else:
                matrix = matrix.reshape(matrix.shape[0], -1)
        else:
            embeddings = list(embeddings)

            if not embeddings:
                return []

            matrix = torch.stack(list(embeddings))

        if (
            self.loss_fn.distance_metric == DistanceMetric.COSINE
            and (self.loss_fn.normalize or assume_normalized)
        ):
            return (1 - (matrix @ emb_a)).detach().cpu().tolist()

        left = emb_a.unsqueeze(0).expand_as(matrix)

        return self.loss_fn.distance(left, matrix).detach().cpu().tolist()

    def training_step(self, batch, batch_idx):
        loss = self.loss_fn([
            batch["start_nodes"],
            batch["end_nodes"],
            batch["positives"],
            batch["negatives"]
        ])

        batch_size = len(batch["start_nodes"])
        self.log("train/loss", loss, prog_bar=True, batch_size=batch_size)
        return loss

    def validation_step(self, batch, batch_idx):
        starts = batch["start_nodes"]
        ends = batch["end_nodes"]

        # Validation is based on actual A* search behavior, not only embedding loss.
        # We deduplicate pairs inside the batch so we do not run the same search twice.
        unique_pairs = list(set(zip(starts, ends)))
        total_visits = 0
        pairs_validated = 0

        for u, v in unique_pairs:
            if (u, v) in self.result_cache:
                visits = self.result_cache[(u, v)]
            else:
                _, visits = traverse_graph(self.graph, u, v, self, ts.astar_traverse, None)
                self.result_cache[(u, v)] = visits

            total_visits += visits
            pairs_validated += 1

        if pairs_validated == 0:
            avg_visited = float("inf")
        else:
            avg_visited = total_visits / pairs_validated

        self.log("val/astar_cost", avg_visited, prog_bar=True, batch_size=max(pairs_validated, 1))

        # Still log the embedding loss as a secondary signal for debugging.
        val_loss = self.loss_fn([
            batch["start_nodes"],
            batch["end_nodes"],
            batch["positives"],
            batch["negatives"]
        ])
        self.log("val/embedding_loss", val_loss, prog_bar=True, batch_size=len(starts))

        return avg_visited

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.hparams.lr)

        # We reduce LR when the actual search cost stops improving.
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=0.5,
            patience=1,
        )

        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "monitor": "val/astar_cost",
                "interval": "epoch",
                "frequency": 1,
            },
        }

    def on_before_optimizer_step(self, optimizer):
        # Logging gradient norm helps spot exploding gradients or dead training.
        grads = [p.grad for p in self.parameters() if p.grad is not None]

        if len(grads) > 0:
            grad_norm = torch.norm(
                torch.stack([torch.norm(g.detach(), 2) for g in grads]),
                2
            )
            self.log("train/grad_norm", grad_norm, prog_bar=True)


def create_dataset(data, graph, embedder):
    astar_cache = {}
    start_nodes, end_nodes, positives, negatives = [], [], [], []

    for i, pair in enumerate(data):
        cause = get_concept(pair, 0)
        effect = get_concept(pair, 1)

        # Cache path generation because the same pair may appear multiple times.
        if (cause, effect) in astar_cache:
            path = astar_cache[(cause, effect)]
        else:
            path, _ = traverse_graph(graph, cause, effect, embedder, ts.astar_traverse, None)
            astar_cache[(cause, effect)] = path

        # We need at least one hop to define a positive next node.
        if len(path) < 2:
            continue

        # For each step on the A* path:
        # - next_node is the positive example
        # - every other successor becomes a negative example
        for j, node in enumerate(path[:-1]):
            next_node = path[j + 1]
            successors = list(graph.successors(node))

            if next_node in successors:
                successors.remove(next_node)

            for successor in successors:
                start_nodes.append(node)
                end_nodes.append(effect)
                positives.append(next_node)
                negatives.append(successor)

    return Dataset.from_dict({
        "start_nodes": start_nodes,
        "end_nodes": end_nodes,
        "positives": positives,
        "negatives": negatives
    })


def load_or_create_datasets(
        model_path,
        curr_model_name,
        distance_metric_str,
        train_data,
        valid_data,
        causal_graph,
        datasets_dir,
):
    distance_metric = parse_distance_metric(distance_metric_str)
    dataset_suffix = f"{curr_model_name.replace('/', '_')}_{distance_metric_str}"

    train_ds_path = datasets_dir / f"train_{dataset_suffix}"
    valid_ds_path = datasets_dir / f"valid_{dataset_suffix}"

    train_exists = train_ds_path.exists()
    valid_exists = valid_ds_path.exists()

    main_embedder = None
    try:
        if not train_exists or not valid_exists:
            print(f"Initializing Embedder for {curr_model_name} with {distance_metric_str} distance ...")
            main_embedder = STEmbedder(model_path, distance_metric)

        if train_exists:
            print(f"Loading cached TRAIN dataset: {train_ds_path}")
            train_dataset = load_from_disk(str(train_ds_path))
        else:
            print(f"Creating TRAIN dataset: {train_ds_path}")
            train_dataset = create_dataset(train_data, causal_graph, main_embedder)
            train_dataset.save_to_disk(str(train_ds_path))
            print(f"TRAIN Dataset saved to: {train_ds_path}")

        if valid_exists:
            print(f"Loading cached VAL dataset: {valid_ds_path}")
            valid_dataset = load_from_disk(str(valid_ds_path))
        else:
            print(f"Creating VAL dataset: {valid_ds_path}")
            valid_dataset = create_dataset(valid_data, causal_graph, main_embedder)
            valid_dataset.save_to_disk(str(valid_ds_path))
            print(f"VAL Dataset saved to: {valid_ds_path}")

        print(f"Total Train examples for {distance_metric_str}: {len(train_dataset)}")
        print(f"Total Val examples for {distance_metric_str}: {len(valid_dataset)}")

        return train_dataset, valid_dataset
    finally:
        if main_embedder is not None:
            del main_embedder
            gc.collect()
            torch.cuda.empty_cache()


def cleanup_zombie_trials(study, label: str = ""):
    # When a run is interrupted, Optuna may leave trials in RUNNING state.
    # Mark them as failed so the study can resume cleanly.
    label_prefix = f"{label} " if label else ""
    print(f"Cleaning zombie {label_prefix}trials ...")

    running_trials = [
        t for t in study.trials
        if t.state == optuna.trial.TrialState.RUNNING
    ]

    if running_trials:
        print(f"Found {len(running_trials)} interrupted {label_prefix}trials (Zombies). Cleaning them up ...")
        for f_trial in running_trials:
            try:
                study.tell(f_trial.number, state=optuna.trial.TrialState.FAIL)
                print(f"Marked interrupted {label_prefix}Trial {f_trial.number} as FAILED.")
            except Exception as e:
                print(f"Warning: Could not update status for {label_prefix}Trial {f_trial.number}: {e}")


def find_latest_hparam_study(
    optuna_hparam_search_dir,
    curr_model_name,
    normalize_str,
    mrl_str,
    run_suffix=None,
    hparam_search_space_slug=None,
    include_slugged_studies=True,
):
    study_prefix = f"{curr_model_name}_{normalize_str}_{mrl_str}_"

    if run_suffix is not None:
        study_prefix += f"{run_suffix}_"

    if hparam_search_space_slug is not None:
        study_prefix += f"{hparam_search_space_slug}_"

    matching_studies = [
        p for p in optuna_hparam_search_dir.glob(f"{study_prefix}*.sqlite3")
        if not p.name.endswith(".sqlite3.sqlite3")
        and (
            hparam_search_space_slug is not None
            or include_slugged_studies
            or not p.stem[len(study_prefix):].startswith("act-")
        )
    ]

    matching_studies = sorted(
        matching_studies,
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not matching_studies:
        return None

    latest_study_path = matching_studies[0]
    storage = f"sqlite:///{latest_study_path}"

    summaries = optuna.study.get_all_study_summaries(storage)

    if not summaries:
        raise RuntimeError(f"No Optuna study found inside SQLite file: {latest_study_path}")

    # Normally there should be only one study per SQLite file.
    # If there are multiple, use the newest one based on datetime_start.
    latest_summary = sorted(
        summaries,
        key=lambda s: s.datetime_start,
        reverse=True,
    )[0]

    return latest_study_path, latest_summary.study_name


def load_hparams(
    optuna_hparam_search_dir,
    curr_model_name,
    normalize_str,
    mrl_str,
    run_suffix=None,
):
    latest_study = find_latest_hparam_study(
        optuna_hparam_search_dir=optuna_hparam_search_dir,
        curr_model_name=curr_model_name,
        normalize_str=normalize_str,
        mrl_str=mrl_str,
        run_suffix=run_suffix,
    )

    if latest_study is None:
        study_prefix = f"{curr_model_name}_{normalize_str}_{mrl_str}_"
        if run_suffix is not None:
            study_prefix += f"{run_suffix}_"
        raise FileNotFoundError(
            f"No Optuna hparam search study found in {optuna_hparam_search_dir} "
            f"starting with: {study_prefix}"
        )

    latest_study_path, study_name = latest_study
    storage = f"sqlite:///{latest_study_path}"

    study = optuna.load_study(
        storage=storage,
        study_name=study_name,
    )

    best_params = study.best_params

    required_params = ["activation", "distance", "lr"]
    missing_params = [p for p in required_params if p not in best_params]

    if missing_params:
        raise KeyError(
            f"Best trial in {latest_study_path} is missing required params: {missing_params}. "
            f"Available params: {best_params}"
        )

    print("=" * 80)
    print("LOADED HPARAM SEARCH STUDY")
    print("=" * 80)
    print(f"Study file: {latest_study_path}")
    print(f"Study name: {study.study_name}")
    print(f"Best value: {study.best_value}")
    print(f"Best params: {best_params}")
    print("=" * 80)

    return best_params, latest_study_path, study.study_name
